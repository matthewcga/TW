package org.example;

interface iSemafor { void V(); void P(); }
