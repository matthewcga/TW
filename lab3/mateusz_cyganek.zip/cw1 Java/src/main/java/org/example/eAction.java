package org.example;

public enum eAction { eats, thinks, finished }
