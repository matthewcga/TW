﻿namespace Lab6_NET.Enums;

public enum EOperation { A, B, C }