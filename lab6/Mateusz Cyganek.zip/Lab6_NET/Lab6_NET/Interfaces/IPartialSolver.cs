﻿namespace Lab6_NET.Interfaces;

public interface IPartialSolver
{ public void SolvePartially(); }