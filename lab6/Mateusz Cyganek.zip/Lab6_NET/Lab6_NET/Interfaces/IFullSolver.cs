﻿namespace Lab6_NET.Interfaces;

public interface IFullSolver : IPartialSolver
{ public void FinishSolving(); }